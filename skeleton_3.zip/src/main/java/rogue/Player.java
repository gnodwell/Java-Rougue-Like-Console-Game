package rogue;
import java.util.ArrayList;
import java.awt.Point;
/**
 * The player character
 */
public class Player {



    // Default constructor
    public Player() {

    }


    public Player(String name) {

    }


    public String getName() {

        return null;
    }


    public void setName(String newName) {

    }

    public Point getXyLocation() {
        return null;

    }


    public void setXyLocation(Point newXyLocation) {

    }


    public Room getCurrentRoom() {
        return null;

    }


    public void setCurrentRoom(Room newRoom) {

    }
}
